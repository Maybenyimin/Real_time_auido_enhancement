import os
import random
import torch
import numpy as np
import soundfile as sf
from torch.utils.data import Dataset


class SpeechDataset(Dataset):
    def __init__(self, noisy_dir, clean_dir, sample_rate=16000, segment_length=2.0):
        """
        Dataset that loads paired noisy and clean audio files.
        """
        self.sample_rate = sample_rate
        self.segment_samples = int(sample_rate * segment_length)

        noisy_files = {
            os.path.splitext(f)[0]: os.path.join(noisy_dir, f)
            for f in os.listdir(noisy_dir)
            if f.endswith('.wav')
        }

        clean_files = {
            os.path.splitext(f)[0]: os.path.join(clean_dir, f)
            for f in os.listdir(clean_dir)
            if f.endswith('.wav')
        }

        common_keys = sorted(set(noisy_files) & set(clean_files))
        assert len(common_keys) > 0, "❌ No matching files found!"

        self.noisy_paths = [noisy_files[k] for k in common_keys]
        self.clean_paths = [clean_files[k] for k in common_keys]

    def __len__(self):
        return len(self.noisy_paths)

    def __getitem__(self, idx):
        noisy_path = self.noisy_paths[idx]
        clean_path = self.clean_paths[idx]

        noisy, _ = sf.read(noisy_path, always_2d=False)
        clean, _ = sf.read(clean_path, always_2d=False)

        # Force mono
        if noisy.ndim > 1:
            noisy = np.mean(noisy, axis=1)
        if clean.ndim > 1:
            clean = np.mean(clean, axis=1)

        # Normalize
        noisy = noisy / (np.max(np.abs(noisy)) + 1e-9)
        clean = clean / (np.max(np.abs(clean)) + 1e-9)

        # Pad or crop
        if len(noisy) < self.segment_samples:
            pad_len = self.segment_samples - len(noisy)
            noisy = np.pad(noisy, (0, pad_len), mode='constant')
            clean = np.pad(clean, (0, pad_len), mode='constant')
        else:
            offset = random.randint(0, len(noisy) - self.segment_samples)
            noisy = noisy[offset:offset + self.segment_samples]
            clean = clean[offset:offset + self.segment_samples]

        return torch.tensor(noisy, dtype=torch.float32), torch.tensor(clean, dtype=torch.float32)