import torchaudio
def load_audio (file_path):
    waveform,sr = torchaudio.load(file_path)
    return waveform, sr