import torch
import numpy as np
from pesq import pesq
from pystoi import stoi


def si_snr(preds, target, eps=1e-8):
    preds_zm = preds - torch.mean(preds, dim=-1, keepdim=True)
    target_zm = target - torch.mean(target, dim=-1, keepdim=True)

    s_target = torch.sum(preds_zm * target_zm, dim=-1, keepdim=True) * target_zm
    s_target /= torch.sum(target_zm ** 2, dim=-1, keepdim=True) + eps

    e_noise = preds_zm - s_target
    si_snr_val = 10 * torch.log10(
        (torch.sum(s_target ** 2, dim=-1) + eps) /
        (torch.sum(e_noise ** 2, dim=-1) + eps)
    )
    return si_snr_val.mean().item()


def compute_metrics(enhanced, clean, sample_rate=16000):
    # ✅ Ensure both arrays have same length and copy to avoid negative strides
    min_len = min(len(enhanced), len(clean))
    enhanced = enhanced[:min_len].copy()
    clean = clean[:min_len].copy()

    # ✅ Normalize to [-1, 1]
    enhanced = enhanced / (np.max(np.abs(enhanced)) + 1e-9)
    clean = clean / (np.max(np.abs(clean)) + 1e-9)

    # ✅ Ensure correct dtype
    enhanced = enhanced.astype(np.float32)
    clean = clean.astype(np.float32)

    # ✅ PESQ
    try:
        pesq_score = pesq(sample_rate, clean, enhanced, 'wb')  # wideband
    except Exception as e:
        print(f"⚠️ PESQ computation failed: {e}")
        pesq_score = 0.0

    # ✅ STOI
    try:
        stoi_score = stoi(clean, enhanced, sample_rate, extended=False)
    except Exception as e:
        print(f"⚠️ STOI computation failed: {e}")
        stoi_score = 0.0

    # ✅ SI-SNR
    try:
        si_snr_score = si_snr(torch.tensor(enhanced.copy()), torch.tensor(clean.copy()))
    except Exception as e:
        print(f"⚠️ SI-SNR computation failed: {e}")
        si_snr_score = 0.0

    return {
        "pesq": pesq_score,
        "stoi": stoi_score,
        "si_snr": si_snr_score
    }