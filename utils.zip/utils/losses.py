# losses.py

import torch


def si_snr_loss(preds: torch.Tensor, target: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """
    Compute Scale-Invariant Signal-to-Noise Ratio (SI-SNR) loss.

    Args:
        preds  : [B, T] enhanced waveform
        target : [B, T] clean waveform
        eps    : Small constant to prevent division by zero

    Returns:
        Scalar tensor (loss)
    """
    # Ensure zero-mean for both
    preds_zm = preds - torch.mean(preds, dim=1, keepdim=True)
    target_zm = target - torch.mean(target, dim=1, keepdim=True)

    # Target projection
    s_target = torch.sum(preds_zm * target_zm, dim=1, keepdim=True) * target_zm
    s_target /= torch.sum(target_zm ** 2, dim=1, keepdim=True) + eps

    # Noise/residual
    e_noise = preds_zm - s_target

    # SI-SNR computation
    si_snr = 10 * torch.log10(
        (torch.sum(s_target ** 2, dim=1) + eps) /
        (torch.sum(e_noise ** 2, dim=1) + eps)
    )

    return -torch.mean(si_snr)  # Return as a loss (negative SI-SNR)