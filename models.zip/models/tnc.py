import torch
import torch.nn as nn

class CausalConvBlock(nn.Module):
    def __init__(self, channels, kernel_size, dilation):
        super().__init__()
        self.pad = (kernel_size -1)*dilation
        self.conv = nn.Conv1d(
            in_channels=channels,
            out_channels=channels,
            kernel_size=kernel_size,
            dilation=dilation,
            padding=self.pad,
            groups=1
        )
        self.relu = nn.ReLU()
        self.norm = nn.LayerNorm(channels)

    def forward(self,x):
        out = self.conv(x)
        out = out[:, :, :-self.pad]  # Remove future context → causal
        out = self.relu(out)
        out = out.transpose(1, 2)    # [B, T, C] for LayerNorm
        out = self.norm(out)
        out = out.transpose(1, 2)    # [B, C, T] back
        return out
    
class TCNBlock(nn.Module):
    def __init__(self, num_blocks=8, channels=256, kernel_size=3, dilation_base=2):
        super(TCNBlock, self).__init__()
        self.blocks = nn.ModuleList()
        for i in range(num_blocks):
            dilation = dilation_base ** i
            self.blocks.append(CausalConvBlock(channels, kernel_size, dilation))

    def forward(self, x):
        """
        Input/output shape: [B, C, T]
        """
        for block in self.blocks:
            residual = x
            x = block(x)
            x = x + residual  # Residual connection
        return x
    
if __name__ == "__main__":
    model = TCNBlock(num_blocks=8, channels=256, kernel_size=3, dilation_base=2)
    dummy_input = torch.randn(2, 256, 1599)
    output = model(dummy_input)
    print("Output shape:", output.shape)