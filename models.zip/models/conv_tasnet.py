import torch
import torch.nn as nn
from models.conv import ConvEncoder, ConvDecoder
from models.tnc import TCNBlock

class ConvTasNet(nn.Module):
    def __init__(self, 
                 enc_kernel_size=32,
                 enc_stride=16,              # consider 8 for smoother output
                 enc_out_channels=256,
                 num_tcn_blocks=8,
                 tcn_kernel_size=3,
                 use_post_conv=True):
        super().__init__()

        # --- Encoder ---
        self.encoder = ConvEncoder(
            in_channels=1,
            out_channels=enc_out_channels,
            kernel_size=enc_kernel_size,
            stride=enc_stride,
            use_relu=True
        )

        # --- TCN Separator (Mask Estimation) ---
        self.separator = TCNBlock(
            channels=enc_out_channels,
            kernel_size=tcn_kernel_size,
            num_blocks=num_tcn_blocks,
            dilation_base=2
        )

        # --- Decoder ---
        self.decoder = ConvDecoder(
            in_channels=enc_out_channels,
            out_channels=1,
            kernel_size=enc_kernel_size,
            stride=enc_stride,
            use_post_conv=use_post_conv
        )

    def forward(self, x):  # x: [B, T]
        # --- Encode ---
        enc = self.encoder(x)            # [B, C, T']

        # --- Mask Estimation ---
        mask = self.separator(enc)      # [B, C, T']
        mask = torch.sigmoid(mask)      # Constrain mask to [0, 1]

        # --- Apply Mask ---
        enhanced = enc * mask           # [B, C, T']

        # --- Decode ---
        out = self.decoder(enhanced)    # [B, T]

        # Optional smoother activation
        # out = torch.tanh(out)

        # Clamp output to avoid saturation
        out = torch.clamp(out, -1.0, 1.0)
        return out