import torch
import torch.nn as nn

class ConvEncoder(nn.Module):
    def __init__(self,out_channels=256, kernel_size=20, stride=10):
        super(ConvEncoder,self).__init__()

        self.conv1d = nn.Conv1d(
            in_channels=1,
            out_channels=out_channels,
            kernel_size=kernel_size,
            stride=stride,
            padding=0,
            bias=False
        )

        self.relu = nn.ReLU()

    def forward(self,x):
        x = self.conv1d(x)
        x = self.relu(x)
        return x
# if __name__ == "__main__":
#     encoder = ConvEncoder(out_channels=256, kernel_size=20, stride=10)
#     dummy_input = torch.randn(4,1,16000)
#     output = encoder(dummy_input)
#     print("Input shape:",dummy_input.shape)
#     print("Output shape:",output.shape)