import torch
import torch.nn as nn

class ConvDecoder(nn.Module):
    def __init__(self, out_channels=1, kernel_size=20, stride=10):
        super(ConvDecoder, self).__init__()
        
        # Transposed convolution (deconvolution) to reconstruct the waveform
        self.deconv = nn.ConvTranspose1d(
            in_channels=256,        # Must match encoder output channels
            out_channels=out_channels,  # Usually 1 (mono audio)
            kernel_size=kernel_size,
            stride=stride,
            bias=False
        )

    def forward(self, x):
        return self.deconv(x)
