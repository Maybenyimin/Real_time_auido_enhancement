import torch
import torch.nn as nn

# Custom LayerNorm block with correct dimension handling
class TransposeLayerNorm(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.norm = nn.LayerNorm(channels)

    def forward(self, x):
        # x: [B, C, T] → [B, T, C] → normalize → [B, T, C] → [B, C, T]
        x = x.transpose(1, 2)
        x = self.norm(x)
        return x.transpose(1, 2)

class ConvEncoder(nn.Module):
    def __init__(self, in_channels=1, out_channels=256, kernel_size=20, stride=10, use_relu=False, use_norm=False):
        super().__init__()
        layers = [nn.Conv1d(in_channels, out_channels, kernel_size, stride=stride)]

        if use_relu:
            layers.append(nn.ReLU())

        if use_norm:
            layers.append(TransposeLayerNorm(out_channels))

        self.encoder = nn.Sequential(*layers)

    def forward(self, x):  # x: [B, T]
        x = x.unsqueeze(1)         # [B, T] → [B, 1, T]
        return self.encoder(x)     # → [B, out_channels, T']

class ConvDecoder(nn.Module):
    def __init__(self, in_channels=256, out_channels=1, kernel_size=20, stride=10, use_post_conv=True):
        super().__init__()
        self.deconv = nn.ConvTranspose1d(in_channels, out_channels, kernel_size, stride=stride)

        self.post_process = nn.Sequential(
            nn.ReLU(),
            nn.Conv1d(out_channels, out_channels, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.Conv1d(out_channels, out_channels, kernel_size=5, padding=2)
        ) if use_post_conv else nn.Identity()

    def forward(self, x):  # x: [B, C, T']
        x = self.deconv(x)         # → [B, 1, T]
        x = self.post_process(x)   # → [B, 1, T]
        return x.squeeze(1)        # → [B, T]
