import torch
import torch.nn as nn
import torch.nn.functional as F

class FeedForwardModule(nn.Module):
    def __init__(self, dim, expansion_factor=4, dropout=0.1):
        super().__init__()
        hidden_dim = dim * expansion_factor
        self.net = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)


class ConvolutionModule(nn.Module):
    def __init__(self, dim, kernel_size=31):
        super().__init__()
        self.pointwise_conv1 = nn.Conv1d(dim, 2 * dim, 1)
        self.depthwise_conv = nn.Conv1d(dim, dim, kernel_size, padding=kernel_size // 2, groups=dim)
        self.norm = nn.BatchNorm1d(dim)
        self.pointwise_conv2 = nn.Conv1d(dim, dim, 1)

    def forward(self, x):
        # x: [B, T, C]
        x = x.transpose(1, 2)  # -> [B, C, T]
        x = self.pointwise_conv1(x)
        x = F.glu(x, dim=1)
        x = self.depthwise_conv(x)
        x = self.norm(x)
        x = F.relu(x)
        x = self.pointwise_conv2(x)
        x = x.transpose(1, 2)  # -> [B, T, C]
        return x


class MultiHeadSelfAttention(nn.Module):
    def __init__(self, dim, num_heads):
        super().__init__()
        self.attn = nn.MultiheadAttention(embed_dim=dim, num_heads=num_heads, batch_first=True)
        self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        attn_output, _ = self.attn(x, x, x)
        return self.norm(x + attn_output)


class CausalSEConformerBlock(nn.Module):
    def __init__(self, dim, num_heads, kernel_size=31, dropout=0.1):
        super().__init__()
        self.ff1 = FeedForwardModule(dim, dropout=dropout)
        self.self_attn = MultiHeadSelfAttention(dim, num_heads)
        self.conv = ConvolutionModule(dim, kernel_size=kernel_size)
        self.ff2 = FeedForwardModule(dim, dropout=dropout)

    def forward(self, x):
        x = x + self.ff1(x)
        x = x + self.self_attn(x)
        x = x + self.conv(x)
        x = x + self.ff2(x)
        return x
