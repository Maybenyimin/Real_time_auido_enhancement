import torch
import torch.nn as nn
from models.conv import ConvEncoder as Encoder, ConvDecoder as Decoder  # ✅ Correct imports
from models.causal_se_conformer import CausalSEConformerBlock

class HybridModel(nn.Module):
    def __init__(self, config):
        super().__init__()

        self.encoder = Encoder(
            out_channels=config["encoder"]["out_channels"],
            kernel_size=config["encoder"]["kernel_size"],
            stride=config["encoder"]["stride"]
        )

        self.bottleneck = nn.Sequential(
            nn.LayerNorm(config["encoder"]["out_channels"]),
            CausalSEConformerBlock(
                dim=config["encoder"]["out_channels"],
                num_heads=config.get("conformer_heads", 4),
                kernel_size=config["tcn"]["kernel_size"],
                dropout=0.1
            )
        )

        self.decoder = Decoder(
            in_channels=config["encoder"]["out_channels"],
            out_channels=config["decoder"]["out_channels"],
            kernel_size=config["encoder"]["kernel_size"],
            stride=config["encoder"]["stride"]
        )

    def forward(self, x):
        # Input: [B, T]
        enc = self.encoder(x)        # [B, C, T']
        enc = enc.transpose(1, 2)    # [B, T', C]
        features = self.bottleneck(enc)  # [B, T', C]
        features = features.transpose(1, 2)  # [B, C, T']
        out = self.decoder(features)  # [B, T]
        return out